from operation import *
from datetime import datetime

purchase_info=[]

def Equipment_ID(equipment_list):
    while True:
        try:
            valid_id=int(input("Please select the item's ID that you wish to rent: "))
            if valid_id > 0 and valid_id <= len(equipment_list):
                return valid_id
            else:
                raise ValueError
            
        except ValueError:
            print ("\nKindly provide a valid item ID to proceed !!!")
            print("\n")
        else:
            break



def Quantity(equipment_list,):
    Eqp_id=Equipment_ID(equipment_list)
    while True:
        try:
            print("\n")
            user_quality = int(input("Please indicate the desired quantity of the item you intend to rent: "))
            get_quality_of_item=int(equipment_list[Eqp_id][3])

            if user_quality > 0 and user_quality < get_quality_of_item:
                Remain_Qnty=get_quality_of_item-user_quality
                equipment_list[Eqp_id][3]=Remain_Qnty
                with open('item.txt','w') as file:
                    for value in equipment_list.values():
                        file.write(str(value[0])+","+str(value[1])+","+str(value[2])+","+str(value[3]))
                        file.write("\n")
                itemPrice=int(equipment_list[Eqp_id][2].replace("$",""))
                total_amount=itemPrice*user_quality
                #print(total_price_of_item)
                equipment_name=equipment_list[Eqp_id][0]
                purchase_info.append([Eqp_id,equipment_name,get_quality_of_item,user_quality,itemPrice,total_amount])

                print("\nThe equipment has been successfully Rented.")
                print("The Equipment Rented is: "+ str(user_quality))
                print("Quantity left in Stock is: "+str(Remain_Qnty))
                print("\n")
            else:
                raise ValueError
        except ValueError:
            print("\nErrro !! Quantity selected is not in stock Quantity available is: "+ str(equipment_list[Eqp_id][3]))
        else:
            break

#Quantity(equipment_list,Eqp_id)

def Equipment_Rent_bill():
    print("\n")
    Cust_name=input("Enter the customer's Name for our records: ")
    Cust_Address=input("Enter the customer's Address: ")
    #Cust_Email=input("Enter the customer's Email Address: ")
    while True:
        try:
            print("\n")
            Cust_phone=int(input("Enter the customer's phone number: +977 "))
            if Cust_phone > 0:
                phone_number=Cust_phone
            else:
                raise ValueError
        except ValueError:
            print("\nPhone number must be in Digit\n")
        else:
            break
    print("\n\n")
    date_Time = datetime.now()
    print("-----------------------------------------------------------------------------------------------")
    print("\t\t\t  Welcome To Jiyansh Store \t\t")
    print("\t       Address: Aloknagar(KTM) | Contact: +977 9814894243.")
    print("-----------------------------------------------------------------------------------------------")
    print("Name of the customer: "+str(Cust_name))
    print("Addr.of the customer: "+str(Cust_Address))
    #print("Email Address of the customer: "+str(Cust_Email))
    print("Con.num of the customer: "+str(phone_number))
    print("Date:"+str(date_Time))
    print("Your Purchasing Detail are: ")
    print("-----------------------------------------------------------------------------------------------")
    print("\t ItemName    \t\t| Quantity of Rented |\t Unit Price \t|  Total Amount")
    print("-----------------------------------------------------------------------------------------------")
    grandtotal=0
    for i in purchase_info:
        #for key, value in EquipmentDictionary.items():
        formatted_output = "{:<32}|    {:<16}|     {:<13}|      {:<8}".format(i[1],i[3],"$"+str(i[4]),"$"+str(i[5]))
        
        # print(i[1],,i[2],,i[3],,"$",i[4])
        grandtotal=grandtotal+i[5]
        print(formatted_output)
    print("-----------------------------------------------------------------------------------------------")
    print("Grand Total\t\t\t\t\t\t\t\t       $"+str(grandtotal))
    print("-----------------------------------------------------------------------------------------------")
    print("Equipment's is for 5 days basis")
    print("Note: Fine will be charged and added into the total amount in case of delay returning")
    print("-----------------------------------------------------------------------------------------------")
    print("\t\t\t*** Thank You-For Renting the Item's ***\t\t\t")
    print("-----------------------------------------------------------------------------------------------")
    with open(str(Cust_name)+".txt","w") as file:
        file.write("\n\n-----------------------------------------------------------------------------------------------")
        file.write("\n\t\t\t        Welcome To Jiyansh Store \t\t")
        file.write("\n\t       Address: Aloknagar(KTM) | Contact: +977 9814894243.")
        file.write("\n-----------------------------------------------------------------------------------------------")
        file.write("\nName of the customer: "+str(Cust_name))
        file.write("\nAddr.of the customer: "+str(Cust_Address))
        file.write("\nCon.num of the customer: "+str(phone_number))
        file.write("\nDate:"+str(date_Time))
        file.write("\nYour Purchasing Detail are: ")
        file.write("\n-----------------------------------------------------------------------------------------------")
        file.write("\n\t ItemName    \t\t\t  | Quantity of Rented |\t Unit Price \t|  Total Amount")
        file.write("\n-----------------------------------------------------------------------------------------------\n")
        grandtotal=0
        for i in purchase_info:
            formatted_output = "{:<25}|    {:<16}|     {:<13}|      {:<8}".format(i[1],i[3],"$"+str(i[4]),"$"+str(i[5]))
            
            grandtotal=grandtotal+i[5]
            file.write(formatted_output)
            file.write("\n")
        file.write("\n-----------------------------------------------------------------------------------------------")
        file.write("\nGrand Total\t\t\t\t\t\t\t\t       $"+str(grandtotal))
        file.write("\n-----------------------------------------------------------------------------------------------")
        file.write("\nEquipment's is for 5 days basis")
        file.write("\nNote: Fine will be charged and added into the total amount in case of delay returning")
        file.write("\n-----------------------------------------------------------------------------------------------")
        file.write("\n\t\t\t*** Thank You-For Renting the Item's ***\t\t\t")
        file.write("\n-----------------------------------------------------------------------------------------------")

#Equipment_Rent_bill()
