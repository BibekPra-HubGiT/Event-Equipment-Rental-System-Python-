from operation import *
from datetime import datetime

return_info=[]

def Equipment_ID(equipment_list):
    while True:
        try:
            valid_id=int(input("Please select the item's ID, which you want to Return : "))
            if valid_id > 0 and valid_id <= len(equipment_list):
                return valid_id
            else:
                raise ValueError
            
        except ValueError:
            print ("\nKindly provide a valid item ID to proceed !!! \n")
        else:
            break



def Quantitys(equipment_list,):
    Eqp_id=Equipment_ID(equipment_list)
    while True:
        try:
            print("\n")
            user_quality = int(input("Select the Quantity of the item, you want to Return: "))
            get_quality_of_item=int(equipment_list[Eqp_id][3])

            if user_quality > 0:
                Remain_in_stock=get_quality_of_item+user_quality
                equipment_list[Eqp_id][3]=Remain_in_stock
                with open('item.txt','w') as file:
                    for value in equipment_list.values():
                        file.write(str(value[0])+","+str(value[1])+","+str(value[2])+","+str(value[3]))
                        file.write("\n")
                itemPrice=int(equipment_list[Eqp_id][2].replace("$",""))
                total_amount_eqp=itemPrice*user_quality
                num_of_days=0
                each_day_fine=0
                #total_price_of_eqp=0
                total_price_of_item=0
                #total_price=0
                print("\n")
                while True:
                    try:
                        num_of_days_Rented_for=int(input("Could you please specify for how many days you have rented the items: "))
                        if num_of_days_Rented_for <= 0 or num_of_days_Rented_for >30:
                            raise ValueError
                        else:
                            if num_of_days_Rented_for % 5 == 0:
                                total_price_of_item=total_amount_eqp*((num_of_days_Rented_for/5))
                            else:
                                total_price_of_item=total_amount_eqp*((num_of_days_Rented_for//5)+1)
                    except ValueError:
                        print("\nThe Days value should be within the range of greater than 0 and less than 30\n")
                    else:
                        break
                print("\n")
                while True:
                    try:
                        num_of_days_Returning_after=int(input("After how many days you are returning the items: "))
                        if num_of_days_Returning_after <= 0 or num_of_days_Returning_after > 30:
                          raise ValueError
                        else:
                            if num_of_days_Returning_after > (((num_of_days_Rented_for//5)+1)*5):
                                num_of_days=num_of_days_Returning_after-(((num_of_days_Rented_for//5)+1)*5)
                                each_day_fine=((5/100)*total_amount_eqp)*num_of_days
                                total_price_of_item=total_price_of_item+each_day_fine
                    except ValueError:
                        print("\nThe Days value should be within the range of greater than 0 and less than 30\n")
                    else:
                        break
                #print(total_price_of_item)
                equipment_name=equipment_list[Eqp_id][0]
                return_info.append([Eqp_id,equipment_name,user_quality,itemPrice,get_quality_of_item,total_amount_eqp,num_of_days,each_day_fine,total_price_of_item])
                print("\nThe Equipment returned successfully !")
                print("Equipment Returning is: "+ str(user_quality))
                print("Quantity in stock is: "+str(Remain_in_stock))
                if num_of_days>0:
                    print("Fine has been charged of "+str(num_of_days) +" days")
                    print("Fine charged amount is : "+str(each_day_fine))
            else:
                raise ValueError
        except ValueError:
            print("\nErrro !! Quantity Returning of the should be grater than 0")
        else:
            break

#Quantity(equipment_list,Eqp_id)

def Equipment_retrning_bill():
    print("\n")
    Cust_name=input("Enter the customer's Name for our records: ")
    Cust_Address=input("Enter the Customer's Address: ")
    #Cust_Email=input("Enter the customer's Email Address: ")
    while True:
        try:
            print("\n")
            Cust_phone=int(input("Enter the customer's phone number: +977 "))
            if Cust_phone > 0:
                phone_number=Cust_phone
            else:
                raise ValueError
        except ValueError:
            print("\nPhone number must be in Digit\n")
        else:
            break
    print("\n\n")
    date_Time = datetime.now()
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("\t\t\t Welcome To Jiyansh Store \t\t")
    print("\t       Address: Aloknagar(KTM) | Contact: +977 9814894243.")
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("Name of the customer:"+str(Cust_name))
    print("Address of the customer: "+str(Cust_Address))
    #print("Email Address of the customer: "+str(Cust_Email))
    print("Contact number: "+str(phone_number))
    print("Date: ",str(date_Time))
    print("Your Returninging Detail are:")
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("Item_Name \t\t\t| Quantity_Returned  |\t Unit_Price \t| Equipment_Charge | Fine_days  |  Fine_Amount  |  Total_Amount")
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    grandtotal=0
    for i in return_info:
        #for key, value in EquipmentDictionary.items():
        formatted_output = "{:<32}|   {:<17}|   {:<15}|   {:<15}|   {:<9}|   {:<12}|   {:<8}".format(i[1],i[2],"$"+str(i[3]),"$"+str(i[5]),i[6],"$"+str(i[7]),"$"+str(i[8]))
        
        grandtotal=grandtotal+i[8]
        print(formatted_output)
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("Grand Total\t\t\t\t\t\t\t\t\t\t\t\t\t\t    $"+str(grandtotal))
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("Equipment's is for 5 days basis.")
    print("Note: Fine might have been charged and added into the total amount in case of delay returning")
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    print("\t\t\t\t\t[1m***Thank You-For Returning the Item's-Visit Again***\t\t\t")
    print("-----------------------------------------------------------------------------------------------------------------------------------------------")
    with open(str(Cust_name)+".txt","w") as file:
        file.write("\n\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\n\t\t\t Welcome To Jiyansh Store \t\t")
        file.write("\n\t       Address: Aloknagar(KTM) | Contact: +977 9814894243")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\nName of the customer:"+str(Cust_name))
        file.write("\nAddress of the customer: "+str(Cust_Address))
        #file.write("Email Address of the customer: "+str(Cust_Email))
        file.write("\nContact number: "+str(phone_number))
        file.write("\nDate: "+str(date_Time))
        file.write("\nYour Returninging Detail are:")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\nItem_Name \t\t\t\t       | Quantity_Returned  |\t Unit_Price \t| Equipment_Charge | Fine_days  |  Fine_Amount  |  Total_Amount")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------\n")
        grandtotal=0
        for i in return_info:
            #for key, value in EquipmentDictionary.items():
            formatted_output = "{:<20}|   {:<17}|   {:<15}|   {:<15}|   {:<9}|   {:<12}|   {:<8}".format(i[1],i[2],"$"+str(i[3]),"$"+str(i[5]),i[6],"$"+str(i[7]),"$"+str(i[8]))
            
            grandtotal=grandtotal+i[8]
            file.write(formatted_output)
            file.write("\n")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\nGrand Total\t\t\t\t\t\t\t\t\t\t\t\t\t\t    $"+str(grandtotal))
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\nEquipment's is for 5 days basis.")
        file.write("\nNote: Fine might have been charged and added into the total amount in case of delay returning")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
        file.write("\n\t\t\t\t\t***Thank You-For Returning the Item's-Visit Again***\t\t\t")
        file.write("\n-----------------------------------------------------------------------------------------------------------------------------------------------")
    #print("\n")

#Equipment_Rent_bill()


