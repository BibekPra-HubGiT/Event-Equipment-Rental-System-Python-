from operation import *
from rent import *
from returning import *

print("----------------------------------------------------------------------------------\n")
print("\t\t\t Welcome To Jiyansh Store \t\t")
print("\t       Address: Aloknagar(KTM) | Contact: +977 9814894243.")
print("----------------------------------------------------------------------------------\n")
print("\t\t  Choose the best option do you want to continue\t\t\n")
print("\n")

def main():
    loop= True
    rent_loop=True
    while True:
        try:
            print(" Click 1 for Rent the items.")
            print(" Click 2 for Returning the items.")
            print(" Click 3 for Exit from the system.")
            print("\n")
            userInput=int(input("Kindly, select the desired operation you wish to proceed with: "))
            print("\n")
        
            
            if userInput==1:
                while loop==True:
                    table(equipment_list)
                    Quantity(equipment_list)

                    while True:
                        try:
                            want_more_item=input("Enter 'yes' if you would like to continue renting additional items or 'no' if you intented to conclude the rental process: ").lower()

                            if want_more_item=="yes":
                                loop=True
                            elif want_more_item=="no":
                                loop=False
                                Equipment_Rent_bill()
                            else:
                                raise ValueError
                        except ValueError:
                            print("Invalid selection !! Make Enter yes or no")
                        else:
                            break
            elif userInput==2:
                while rent_loop==True:
                    table(equipment_list)
                    Quantitys(equipment_list)
                    while True:
                        try:
                            want_more_item=input("Enter 'yes' if you intend to proceed with further returns or 'no' if you wish to conclude the returning process: ").lower()

                            if want_more_item=="yes":
                                rent_loop=True
                            elif want_more_item=="no":
                                rent_loop=False
                                Equipment_retrning_bill()
                            else:
                                raise ValueError
                        except ValueError:
                            print("Invalid selection !! Make Enter yes or no ")
                        else:
                            break
            elif userInput==3:
                exit()
            else:
                raise ValueError
        except ValueError:
            print("\nMake a valid selection from below: ")
            print("\n")
        else:
            break

main()
