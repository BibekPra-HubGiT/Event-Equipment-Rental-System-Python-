def read_txt_dict():
    with open('item.txt','r') as file:
        Equipment_dict = {}
        Item_ID = 1
        for txt_line in file:
            txt_line = txt_line.replace('\n', '')
            Equipment_dict[Item_ID] = txt_line.split(',')
            Item_ID = Item_ID + 1

    return Equipment_dict

equipment_list = read_txt_dict()


def table(equipment_list):
    print("----------------------------------------------------------------------------------------------")
    # This can make the line bold and how to set the color of the text-field like \033[1;32m....\033[Om
    print("\t\t\t\t⭐️  Available Item's Menu ⭐️\t\t")
    print("----------------------------------------------------------------------------------------------")
    # Add columns to the table
    print("S.N |   Name of Items      \t\t|   Logo or Brand's     |   Price    |   Quantity")
    print("----------------------------------------------------------------------------------------------")

    for key, value in equipment_list.items():
        #how the values will be placed in the final string-This is a placeholder for a value like the '<' symbol indicates left alignment within a field width of 4 or 32 or 20 or 9 or 8 characters.
        formatted_output = "{:<4}|   {:<32}|   {:<20}|   {:<9}|   {:<8}".format(
            key, value[0], value[1], value[2], value[3])
        print(formatted_output)
        # This can make the line bold, like \033[1m....\033[Om
    print("----------------------------------------------------------------------------------------------")

print("\n\n")

